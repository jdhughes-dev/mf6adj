# imports
from xmipy.xmi import Xmi
from xmipy.xmiwrapper import XmiWrapper

__version__ = "1.0.0"
